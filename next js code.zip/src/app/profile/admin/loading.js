import React from 'react'

const Loading = () => {
    return (
        <div>LOADING...</div>
    )
}

export default Loading