import React from 'react'

const page = () => {
    return (
        <>
            <div className='bg-base-200'>

                <div className='container m-auto p-2 '>
                    <h1>this is profile page</h1>
                    {/* <img src="/Assets/img/img1.png" alt="" /> */}
                </div>
            </div>
        </>
    )
}

export default page